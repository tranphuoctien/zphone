<?php
set_time_limit(999999999999);
/*
Plugin Name: Sock News Plugin
Plugin URI: http://graemewilson.co.nz/wordpress-plugins/wordpress-blank-plugin/
Description: A Sock news plugin that simply adds a new news from other site have been configed before.
             Documented with links to WordPress Codex
Author: 2T-Group 
Author URI:http://sock.vn/
Version: 0.1
License: GPLv2
*/

/*
This program is free software; you can redistribute it and/or modify 
it under the terms of the GNU General Public License as published by 
the Free Software Foundation; version 2 of the License.

This program is distributed in the hope that it will be useful, 
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the 
GNU General Public License for more details. 

You should have received a copy of the GNU General Public License 
along with this program; if not, write to the Free Software 
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA 
*/

/*
GENERAL NOTES

 * PHP short tags ( e.g. <?= ?> ) are not used as per the advice from PHP.net
 * No database implementation
 * IMPORTANT: Menu is visible to anyone who has 'read' capability, so that means subscribers
              See: http://codex.wordpress.org/Roles_and_Capabilities for information on appropriate settings for different users

*/

// Make sure that no info is exposed if file is called directly -- Idea taken from Akismet plugin
if ( !function_exists( 'add_action' ) ) {
	echo "This page cannot be called directly.";
	exit;
}

// Define some useful constants that can be used by functions
if ( ! defined( 'WP_CONTENT_URL' ) ) {	
	if ( ! defined( 'WP_SITEURL' ) ) define( 'WP_SITEURL', get_option("siteurl") );
	define( 'WP_CONTENT_URL', WP_SITEURL . '/wp-content' );
}
if ( ! defined( 'WP_SITEURL' ) ) define( 'WP_SITEURL', get_option("siteurl") );
if ( ! defined( 'WP_CONTENT_DIR' ) ) define( 'WP_CONTENT_DIR', ABSPATH . 'wp-content' );
if ( ! defined( 'WP_PLUGIN_URL' ) ) define( 'WP_PLUGIN_URL', WP_CONTENT_URL. '/plugins' );
if ( ! defined( 'WP_PLUGIN_DIR' ) ) define( 'WP_PLUGIN_DIR', WP_CONTENT_DIR . '/plugins' );

if ( basename(dirname(__FILE__)) == 'plugins' )
	define("BLANK_DIR",'');
else define("BLANK_DIR" , basename(dirname(__FILE__)) . '/');
define("BLANK_PATH", WP_PLUGIN_URL . "/" . BLANK_DIR);

/* Add new menu */
add_action('admin_menu', 'socknews_add_pages');

/*
******** BEGIN PLUGIN FUNCTIONS ********
*/


// function for: 
function socknews_add_pages() {

  // anyone can see the menu for the Blank Plugin
  add_menu_page('Sock News','Sock News', 'manage_options', 'sock_news', 'socknews_setting_page', BLANK_PATH.'images/b_status.png');
  // http://codex.wordpress.org/Function_Reference/add_menu_page

  // this is just a brief introduction
  //add_submenu_page('sock_news', 'Plugin CURL get News from other site!', 'Get news other site', 'read', 'sock_news', 'socknews_intro');
  // http://codex.wordpress.org/Function_Reference/add_submenu_page

}

/* add js,css */
function socknews_set_js_style()
{
    // Register the script like this for a plugin:
    wp_enqueue_script('socknews-jquery',(BLANK_PATH.'js/jquery.min.js'), array('jquery'));
    wp_enqueue_script('socknews-c-jquery',(BLANK_PATH.'js/socknews.js'));
   
}
/* add js,css */
//add_action('admin_enqueue_scripts','socknews_set_js_style');

add_action('wp_ajax_socknews_action', 'get_data_search');


function socknews_setting_page(){
	//$url = 'http://timkiem.vnexpress.net/?q=c%C6%B0%E1%BB%9Bp+c%E1%BB%A7a';
//	$args = array(
//	    'headers' => array( "Content-type" => "html/text" )
//	);
	//$response = wp_remote_get($url, $args );
	
	//echo htmlentities2(wp_remote_retrieve_body($response));	
	
       get_data_search();
     
?>

<!--
<div class="wrap">
    <h2><img src="<?php echo BLANK_PATH.'images/b_status.png'; ?>" /> Sock News </h2>

    <form method="post" action="options.php">

        <table class="form-table">
            
            <tr valign="top">
                <th scope="row">Site Get News</th>
                <td>
                    <select id="socknews_site" name="socknews_site">
                        <option value="VN_EXP">VNEXPRESS</option>
                        <option value="VUI_VIET">VUIVIET</option>
                    </select>
                </td>
            </tr>

             <tr valign="top">
                <th scope="row">Key search</th>
                <td><input placeholder="Key search" type="text" id="socknews_keyseach" name="socknews_keyseach"/></td>
            </tr>

            <tr valign="top">
                <th scope="row">Search</th>
                <td><input type="button" name="socknews_search" id="socknews_search" class="button button-primary" value="Run"></td>
            </tr>
            
        </table>
        
        <h1>Result</h1>
        <div id="result"></div>
    </form>
</div>-->





<?php }

 function get_site()
 {
     return isset($_POST['socknews_site'])?$_POST['socknews_site']:NULL;
 }
 
 
 function get_search_key()
 {
     return isset($_POST['socknews_keyseach'])?$_POST['socknews_keyseach']:NULL;
 }
 
 
 function get_data_search()
 {
     //$site_name = get_site();
     //$search_key= str_replace(" ","+",get_search_key());
     $search_key=array(         
         'vnexpress'=>array(
             'http://timkiem.vnexpress.net/?q=h%C3%A0i+h%C6%B0%E1%BB%9Bc',             
          ),
         'yeah1'=>array(
             'http://yeah1.com/an-choi',
             'http://yeah1.com/xu-huong',
             'http://yeah1.com/nhan-gui-yeu-thuong',
             'http://yeah1.com/xita-viet',
          ),
         'video'=>array(
             'https://www.youtube.com/user/videohaivlhd/videos',
             'https://www.youtube.com/results?search_query=hai+huoc',
             'https://www.youtube.com/user/2idolshow/videos',
             'https://www.youtube.com/user/binhluandabong/videos',
             'https://www.youtube.com/channel/UC2yh1NCj_FeiKVViRKeg-IQ/videos'
          )         
     );
     
     $site_name=isset($_REQUEST['nguon'])?$_REQUEST['nguon']:NULL;
     
     $arg = array(
         
                'headers' => array(
                "Content-type" => "application/x-www-form-urlencoded;charset=UTF-8",
                'Accept'=>'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8, image/gif, image/x-bitmap, image/jpeg, image/pjpeg',
                'Connection'=>'Keep-Alive',
                )
            );
     
     
     switch ($site_name) {
         
         case 'vnexpress':       
            foreach($search_key['vnexpress'] as $tmp){
              for($i=1;$i<10;$i++)
                get_news_vnexpress($tmp.'&page='.$i, $arg);
            }              
         break;
         case 'yeah1':                        
            foreach($search_key['yeah1'] as $tmp){
              for($i=0;$i<10;$i++)
                get_news_yeah1($tmp.'/'.$i*15,$arg);
            }              
         case 'video':                
            foreach($search_key['video'] as $tmp){                    
              get_video($tmp, $arg);              
            }
         break;
         default:
             break;
     }
     
 }

/**
* get video 
*/
function get_video($url,$arg){
  $responseSearch = wp_remote_get($url, $arg );
  //echo htmlspecialchars($responseSearch['body']);
  preg_match_all('#<h3 class=\"yt-lockup-title\".*?href=\"(.+?)\"#mis', $responseSearch['body'], $matchSearch);  
  
  foreach($matchSearch[1] as $tmp){

    $link_video = 'http://youtube.com'.$tmp;
    preg_match_all('#watch\?v=(.+?)(&|$)#mis', $link_video,$id_video);        
    
    if($id_video[1][0]){
        $responsePost = wp_remote_get($link_video, $arg);

      //echo htmlspecialchars($responsePost['body']);
        preg_match_all('#<span id=\"eow-title\".*?title=\"(.+?)\".*?<p id=\"eow-description\" >(.+?)<\/p>#mis', $responsePost['body'], $matchPost);

      //prepared to insert database
        $post_title=isset($matchPost[1][0])?$matchPost[1][0]:NULL;
        $post_excerpt=isset($matchPost[2][0])?$matchPost[2][0]:NULL;
        $post_content= preg_replace('#<a.*?<\/a>#mis','',$matchPost[2][0]);

      if(socknews_check_post_exist(wp_strip_all_tags($post_title))==TRUE):
      // Create post object
        $my_post = array(
          'post_title'    => wp_strip_all_tags($post_title),
          'post_content'  => $post_content,
          'post_excerpt'=>$post_excerpt,
          'post_status'   => 'publish',
          'post_type'=>'post',
          'post_author'   => 1,
          'tags_input' =>'youtube',
          'post_category' => array(21)
        );
      // Insert the post into the database                
        $post_id=wp_insert_post($my_post); 

        add_post_meta($post_id, '_pukka_media_url',$link_video);
        set_post_format($post_id, 'video'); 
        //socknews_random_box($post_id,1);        
    endif;
    }    
  }  
}
/**
*   get news from yeah1
*/
function get_news_yeah1($url,$arg){    

    $responseSearch = wp_remote_get($url, $arg );
    //echo htmlspecialchars($responseSearch['body']);
    //regex get link post
    preg_match_all('#<h3.*?<a href=\"(.+?)\"#mis', $responseSearch['body'], $matchSearch);
     
    for($i=1;$i<count($matchSearch[1]);$i++){
        $tmp = $matchSearch[1][$i];        
        //get url posts
        $responsePost = wp_remote_get($tmp, $arg );
        //echo htmlspecialchars($responsePost['body']);
        
        //regex post    
        preg_match_all('#<h1.*?>(.+?)<\/h1>.*?<article.*?<b>(.*?)<\/b>.*?<\/span>(.+?)<\/article>#mis', $responsePost['body'], $matchPost);
        
        //prepared to insert database
        $post_title=isset($matchPost[1][0])?$matchPost[1][0]:NULL;
        $post_excerpt=isset($matchPost[2][0])?$matchPost[2][0]:NULL;
        $post_content=isset($matchPost[3][0])?$matchPost[3][0]:NULL;
        
        if(socknews_check_post_exist(wp_strip_all_tags($post_title))==TRUE):
            //replace content post
            $post_content=preg_replace('#<br.*?>|<div.*?>|<\/div>|<!--.*?->| style=\".*?\"|<a.*?<\/a>|<script.*?<\/script>|<div class=\"random_link\">.*?<\/div>#mis', '', $post_content);
    
            // Create post object
            $my_post = array(
              'post_title'    => wp_strip_all_tags($post_title),
              'post_content'  => $post_content,
              'post_excerpt'=>$post_excerpt,
              'post_status'   => 'publish',
              'post_type'=>'post',
              'post_author'   => 1,
              'tags_input' =>'yeah1',
              'post_category' => array(18)
            );
    
            // Insert the post into the database                
            $post_id=wp_insert_post($my_post);        
            
            //regex image
            $j=0;
            $posts='';
            foreach (catch_that_image($post_content) as $rows) {                 
                    //get image for posts
                    $file = media_sideload_image($rows,$post_id,$post_excerpt);
                    //replace posts
                    preg_match_all('#(.*?)<img#mis', $post_content, $matches,1);
                    
                    $posts=$posts.$matches[1][0].$file;
    
                    $post_content=preg_replace('#.*?<img.*?\/>|.*?<img.*?<\/img>#mis', '', $post_content,1);
                    //thumbnail anh
                    if($j==0){
                        $attached=array_values(get_attached_media('image', $post_id));                
                        isset($attached[0])?set_post_thumbnail($post_id,$attached[0]->ID):NULL;                        
                    }$j=1;                                                
            }        
            //update post                   
            $my_post = array(
                'ID'           => $post_id,
                'post_content' => $posts.$post_content
            );           

            // Update the post into the database
            wp_update_post($my_post);
            // call function random box.
            socknews_random_box($post_id,1);
            
        endif;       
    }
}
/**
*   get news from vnexpress.net
*/
 function get_news_vnexpress($url,$arg)
 {
     $responseSearch = wp_remote_get($url, $arg );		
     //echo htmlspecialchars($responseSearch['body']);
     //regex get link post
     preg_match_all('#<li.*?<div class=\"title_news\">.*?<a href=\"(.+?)\"#mis', $responseSearch['body'], $matchSearch);
     
    foreach($matchSearch[1] as $tmp){
    
            //get url posts
            $responsePost = wp_remote_get($tmp, $arg );   
            //regex post    
            preg_match_all('#<div class=\"title_news\">.*?<h1>(.+?)<\/h1>.*?<div class=\"short_intro txt_666\">(.*?)<\/div>.*?<div class=\"fck_detail width_common\">(.+?)<\/div>#mis', $responsePost['body'], $matchPost);
            
//             echo "<pre>";
//             print_r($matchPost);
//             echo "</pre>";
//             print_r($matchPost[2][0]);
          
                $post_title=isset($matchPost[1][0])?$matchPost[1][0]:NULL;
                $post_excerpt=isset($matchPost[2][0])?$matchPost[2][0]:NULL;
                $post_content=isset($matchPost[3][0])?$matchPost[3][0]:NULL;               

        if(socknews_check_post_exist(wp_strip_all_tags($post_title))==TRUE):
                // Create post object
                $my_post = array(
                  'post_title'    => wp_strip_all_tags($post_title),
                  'post_content'  => $post_content,
                  'post_excerpt'=>$post_excerpt,
                  'post_status'   => 'publish',
                  'post_type'=>'post',
                  'post_author'   => 1,
                  'tags_input' =>'vnexpress',
                  'post_category' => array(19)
                );
                
                // Insert the post into the database                
                $post_id=wp_insert_post($my_post);
                //regex image
                $i=0;
                foreach (catch_that_image($post_content) as $rows) {                    
                    //get image for posts
                    $file = media_sideload_image($rows,$post_id,$post_excerpt);
                    $post_content=preg_replace('#<table.*?<img.*?src=\".*?\".*?<\/table>#mis', $file, $post_content,1);
                    //thumbnail anh
                    if($i==0){
                        $attached=array_values(get_attached_media('image', $post_id));                
                        isset($attached[0])?set_post_thumbnail($post_id,$attached[0]->ID):NULL;                        
                    }$i=1;                    
                }
                //replace content post
                $post_content=preg_replace('#<table.*?<td>|<\/\w{2,5}>|<\w{0,4}>|<a.*?>|</a>| class=\".*?\"| style=\".*?\"#mis', '', $post_content);
                //update post                   
                $update_post = array(
                    'ID'           => $post_id,
                    'post_content' => $post_content
                );

                // Update the post into the database
                wp_update_post($update_post);
                
                // call function random box.
                socknews_random_box($post_id,1);
                
            endif;
               
                
                //die();
    }
 }
 
function catch_that_image($body=NULL) {    
    //get link image                
    preg_match_all('#<img.*?src=\"(.+?)\"#mis', $body, $matches);    
    return !empty($matches[1])?$matches[1]:array();
}


function socknews_random_box($post_id=NULl,$rand=0,$size='small')
{
    if(is_null($post_id))
    {
        return FALSE;
        
    }
    
    $data_box_size=array(0=>'big',1=>'medium');
    
    if($rand==0)
    {
    
        switch ($size) {

            case 'medium':return add_post_meta($post_id, '_pukka_box_size',$data_box_size[1]);
                break;
            case 'big':return add_post_meta($post_id, '_pukka_box_size',$data_box_size[0]);
                break;

            default:return add_post_meta($post_id, '_pukka_box_size',$data_box_size[1]);
                break;
        }
    }
    
    // random get key array
    $random_keys=array_rand($data_box_size,1);
    // update box size
    return add_post_meta($post_id, '_pukka_box_size',$data_box_size[$random_keys]);
    
}


// function check post exist
function socknews_check_post_exist($title=NUll)
{
    if(is_null($title))
    {
        return FALSE;
    }
    
    $post=get_page_by_title($title,'OBJECT','post');
    
    if(is_object($post))
    {
        return FALSE;
    }
    else
    {
        return TRUE;
    }
    
}


?>
